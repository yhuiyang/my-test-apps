            Total Phase Aardvark Firmware Upgrade Utility
            ---------------------------------------------

Contents
--------
aaflash-linux      - Upgrade utility for Linux
aaflash-win32.exe  - Upgrade utility for Windows
aaflash-darwin     - Upgrade utility for Darwin / Mac OS X


Notes
-----
All Aardvark firmware versions from v3.00 onward use a direct USB
communications driver.  This is a different driver than the virtual
serial port driver used for firmware versions earlier than v3.00.

If the direct driver has not been previously installed on the host
PC, the user can download it from the Total Phase website under the
current downloads section.  It will be required at the end of the
firmware update process.


Instructions
------------
1) Connect the devices to be upgraded.

2) Run the appropriate utility.

3) A list of attached devices will be displayed.

   If the current firmware version on the device is earlier than
   v3.00, the device will be displayed with a "serial" notation.
   Otherwise it will be displayed as a "direct" device.

4) Select the desired device to be upgrade and press <ENTER>.

5) Device will be upgrade to the given firmware version.

   If you are upgrading a device with a firmware version earlier
   than v3.00, the host PC may require some configuration before
   you can communicate with the Aardvark adapter.
   
     Under Windows:
       You will be prompted for the new direct drivers.  Follow the
       instructions in the Aardvark Datasheet v3.00 on how to proceed.
       
     Under Linux:
       You will have to ensure that the access permissions on certain
       operating system files are correct.  Follow the instructions
       in the Aardvark Datasheet v3.00 on how to proceed.

     Under Darwin:
       You must upgrade the device as the currently logged in user.
       Follow the instructions in the Aardvark Datasheet v3.00 on
       how to proceed.

6) The new direct drivers can coexist with the older virtual serial
   port drivers and Total Phase does not recommend removing the
   older drivers.  However, if absolutely necessary, the user can
   choose to remove the virtual serial port drivers by following the
   instructions in the Aardvark Datasheet v2.50. 
